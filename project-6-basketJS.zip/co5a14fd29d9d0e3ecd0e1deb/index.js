let scoreH = 0;
scoreEl1 = document.getElementById("marc1")
let score = 0;   
scoreEl2 = document.getElementById("marc2")

function sum1H() {
     scoreH += 1;
     scoreEl1.innerText = scoreH;
    }
    
function sum2H() {
     scoreH += 2;
     scoreEl1.innerText = scoreH;
    }
    
function sum3H() {
     scoreH += 3;
     scoreEl1.innerText = scoreH;
    }

function sum1() {
     score += 1;
     scoreEl2.innerText = score;
    }
    
function sum2() {
     score += 2;
     scoreEl2.innerText = score;
    }
    
function sum3() {
     score += 3;
     scoreEl2.innerText = score;
    }

function reset() {
    scoreH = 0;
    score = 0;
    scoreEl1.innerText = scoreH;
    scoreEl2.innerText = score;
}